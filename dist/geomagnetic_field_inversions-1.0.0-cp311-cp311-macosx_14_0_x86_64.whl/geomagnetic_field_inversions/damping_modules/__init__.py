from .damping import damp_matrix, damp_norm
from .damp_types import dampingtype
